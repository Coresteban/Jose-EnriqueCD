
<?php
include("conexion.php");

// Buscar productos
$buscar = isset($_GET['buscar']) ? trim($_GET['buscar']) : "";
$categoria = isset($_GET['categoria']) ? $_GET['categoria'] : "";

// Consulta principal
$sql = "SELECT * FROM productos WHERE 1=1";
$parametros = [];
$tipos = "";

if ($buscar !== "") {
    $sql .= " AND (nombre LIKE ? OR sabor LIKE ?)";
    $busqueda = "%".$buscar."%";
    $parametros[] = $busqueda;
    $parametros[] = $busqueda;
    $tipos .= "ss";
}

if ($categoria !== "") {
    $sql .= " AND categoria = ?";
    $parametros[] = $categoria;
    $tipos .= "s";
}

$sql .= " ORDER BY id_producto DESC";

$stmt = $conexion->prepare($sql);

if (!empty($parametros)) {
    $stmt->bind_param($tipos, ...$parametros);
}

$stmt->execute();
$resultado = $stmt->get_result();

// Estadísticas
$totalProductos = $conexion->query(
    "SELECT COUNT(*) AS total FROM productos"
)->fetch_assoc()['total'];

$totalUnidades = $conexion->query(
    "SELECT COALESCE(SUM(stock), 0) AS total FROM productos"
)->fetch_assoc()['total'];

$pocoStock = $conexion->query(
    "SELECT COUNT(*) AS total FROM productos WHERE stock <= 5"
)->fetch_assoc()['total'];

$disponibles = $conexion->query(
    "SELECT COUNT(*) AS total FROM productos WHERE disponible = 1"
)->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IceCream Store</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f7f4fa;
            color: #333;
        }

        .sidebar {
            width: 240px;
            height: 100vh;
            background: #30243f;
            color: white;
            position: fixed;
            padding: 30px 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #ffb6d5;
            margin-bottom: 45px;
        }

        .sidebar p {
            margin: 22px 0;
            color: #ddd;
            font-size: 14px;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 13px;
            margin-bottom: 10px;
            border-radius: 8px;
        }

        .sidebar a:hover,
        .sidebar a.activo {
            background: #59446e;
        }

        .contenido {
            margin-left: 240px;
            padding: 35px;
        }

        .encabezado {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .encabezado h1 {
            color: #30243f;
            font-size: 28px;
        }

        .encabezado p {
            color: #777;
            margin-top: 7px;
        }

        .boton {
            background: #e96da6;
            color: white;
            text-decoration: none;
            padding: 12px 18px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: bold;
        }

        .boton:hover {
            background: #d64f8e;
        }

        .estadisticas {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .tarjeta {
            background: white;
            padding: 23px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.05);
        }

        .tarjeta p {
            color: #777;
            font-size: 14px;
            margin-bottom: 12px;
        }

        .tarjeta h2 {
            font-size: 28px;
            color: #30243f;
        }

        .panel {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.05);
        }

        .panel h2 {
            color: #30243f;
            margin-bottom: 20px;
        }

        .filtros {
            display: flex;
            gap: 12px;
            margin-bottom: 22px;
        }

        input, select {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            outline: none;
        }

        input:focus, select:focus {
            border-color: #e96da6;
        }

        .filtros input {
            flex: 1;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 15px 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
            font-size: 14px;
        }

        th {
            color: #777;
            background: #faf7fc;
        }

        .estado {
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            background: #e2f7e9;
            color: #238344;
        }

        .agotado {
            background: #ffe5e5;
            color: #c0392b;
        }

        .accion {
            text-decoration: none;
            margin-right: 8px;
            font-weight: bold;
        }

        .editar {
            color: #3979c7;
        }

        .eliminar {
            color: #df4b4b;
        }

        .mensaje {
            padding: 13px;
            background: #e2f7e9;
            color: #238344;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .sin-resultados {
            text-align: center;
            padding: 25px;
            color: #888;
        }

        @media(max-width: 1000px) {
            .estadisticas {
                grid-template-columns: repeat(2, 1fr);
            }

            .contenido {
                overflow-x: auto;
            }
        }

        @media(max-width: 650px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .contenido {
                margin-left: 0;
                padding: 18px;
            }

            .estadisticas {
                grid-template-columns: 1fr;
            }

            .filtros {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

<div class="sidebar">

    <div class="logo">🍦 IceCream Store</div>

    <p>MENÚ PRINCIPAL</p>

    <a href="index.php" class="activo">🏠 Panel principal</a>
    <a href="registrar.php">➕ Registrar helado</a>
    <a href="index.php">📦 Inventario</a>

</div>

<div class="contenido">

    <div class="encabezado">
        <div>
            <h1>Panel principal</h1>
            <p>Administración de productos de la heladería.</p>
        </div>

        <a href="registrar.php" class="boton">
            + Nuevo helado
        </a>
    </div>

    <?php if (isset($_GET['mensaje'])): ?>
        <div class="mensaje">
            <?php
            if ($_GET['mensaje'] == 'registrado') {
                echo "¡Helado registrado correctamente!";
            } elseif ($_GET['mensaje'] == 'actualizado') {
                echo "¡Helado actualizado correctamente!";
            } elseif ($_GET['mensaje'] == 'eliminado') {
                echo "¡Helado eliminado correctamente!";
            }
            ?>
        </div>
    <?php endif; ?>

    <div class="estadisticas">

        <div class="tarjeta">
            <p>🍦 Tipos de productos</p>
            <h2><?php echo $totalProductos; ?></h2>
        </div>

        <div class="tarjeta">
            <p>📦 Unidades en inventario</p>
            <h2><?php echo $totalUnidades; ?></h2>
        </div>

        <div class="tarjeta">
            <p>⚠️ Poco stock (5 o menos)</p>
            <h2><?php echo $pocoStock; ?></h2>
        </div>

        <div class="tarjeta">
            <p>✅ Productos disponibles</p>
            <h2><?php echo $disponibles; ?></h2>
        </div>

    </div>

    <div class="panel">

        <h2>Inventario de helados</h2>

        <form method="GET" class="filtros">

            <input
                type="text"
                name="buscar"
                placeholder="Buscar por nombre o sabor..."
                value="<?php echo htmlspecialchars($buscar); ?>"
            >

            <select name="categoria">

                <option value="">Todas las categorías</option>

                <?php
                $categorias = [
                    "Helado de crema",
                    "Helado de agua",
                    "Paleta",
                    "Malteada",
                    "Cono",
                    "Postre helado",
                    "Otro"
                ];

                foreach ($categorias as $cat):
                ?>

                    <option
                        value="<?php echo htmlspecialchars($cat); ?>"
                        <?php echo ($categoria == $cat) ? "selected" : ""; ?>
                    >
                        <?php echo htmlspecialchars($cat); ?>
                    </option>

                <?php endforeach; ?>

            </select>

            <button type="submit" class="boton">Buscar</button>

            <a href="index.php" class="boton">Limpiar</a>

        </form>

        <table>

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Sabor</th>
                    <th>Categoría</th>
                    <th>Tamaño</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>

            <tbody>

                <?php if ($resultado->num_rows > 0): ?>

                    <?php while ($producto = $resultado->fetch_assoc()): ?>

                        <tr>

                            <td><?php echo $producto['id_producto']; ?></td>

                            <td>
                                <?php echo htmlspecialchars($producto['nombre']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($producto['sabor']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($producto['categoria']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($producto['tamano']); ?>
                            </td>

                            <td>
                                $<?php echo number_format($producto['precio'], 2); ?>
                            </td>

                            <td><?php echo $producto['stock']; ?></td>

                            <td>
                                <?php if ($producto['disponible'] == 1): ?>
                                    <span class="estado">Disponible</span>
                                <?php else: ?>
                                    <span class="estado agotado">Agotado</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <a
                                    class="accion editar"
                                    href="editar.php?id=<?php echo $producto['id_producto']; ?>"
                                >
                                    Editar
                                </a>

                                <a
                                    class="accion eliminar"
                                    href="eliminar.php?id=<?php echo $producto['id_producto']; ?>"
                                    onclick="return confirm('¿Estás seguro de eliminar este helado?')"
                                >
                                    Eliminar
                                </a>
                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="9" class="sin-resultados">
                            No hay productos registrados.
                        </td>
                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>

<?php
$stmt->close();
$conexion->close();
?>
