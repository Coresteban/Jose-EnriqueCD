
<?php

include("conexion.php");

// Comprobar que se recibió un ID válido
if (!isset($_GET["id"]) || !ctype_digit($_GET["id"])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET["id"];

// Preparar la consulta para eliminar
$sql = "DELETE FROM productos WHERE id_producto = ?";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {

    $stmt->close();
    $conexion->close();

    header("Location: index.php?mensaje=eliminado");
    exit;

} else {

    $stmt->close();
    $conexion->close();

    header("Location: index.php?mensaje=error");
    exit;
}

?>
