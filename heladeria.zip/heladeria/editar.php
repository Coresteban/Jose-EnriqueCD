
<?php
include("conexion.php");

if (!isset($_GET["id"]) || !ctype_digit($_GET["id"])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET["id"];

$sql = "SELECT * FROM productos WHERE id_producto = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows == 0) {
    $stmt->close();
    $conexion->close();
    header("Location: index.php");
    exit;
}

$producto = $resultado->fetch_assoc();
$stmt->close();

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = trim($_POST["nombre"]);
    $sabor = trim($_POST["sabor"]);
    $categoria = trim($_POST["categoria"]);
    $tamano = trim($_POST["tamano"]);
    $precio = $_POST["precio"];
    $stock = $_POST["stock"];

    if (
        $nombre == "" ||
        $sabor == "" ||
        $categoria == "" ||
        $tamano == "" ||
        $precio == "" ||
        $stock == ""
    ) {
        $error = "Todos los campos son obligatorios.";
    } elseif (!is_numeric($precio) || $precio <= 0) {
        $error = "El precio debe ser mayor que cero.";
    } elseif (filter_var($stock, FILTER_VALIDATE_INT) === false || $stock < 0) {
        $error = "El stock debe ser un número entero igual o mayor que cero.";
    } else {

        $disponible = ($stock > 0) ? 1 : 0;

        $sql = "UPDATE productos SET
                nombre = ?,
                sabor = ?,
                categoria = ?,
                tamano = ?,
                precio = ?,
                stock = ?,
                disponible = ?
                WHERE id_producto = ?";

        $stmt = $conexion->prepare($sql);

        $stmt->bind_param(
            "ssssdiii",
            $nombre,
            $sabor,
            $categoria,
            $tamano,
            $precio,
            $stock,
            $disponible,
            $id
        );

        if ($stmt->execute()) {
            $stmt->close();
            $conexion->close();

            header("Location: index.php?mensaje=actualizado");
            exit;
        } else {
            $error = "No se pudieron actualizar los datos.";
            $stmt->close();
        }
    }

    // Conservar los datos escritos si existe un error
    $producto["nombre"] = $nombre;
    $producto["sabor"] = $sabor;
    $producto["categoria"] = $categoria;
    $producto["tamano"] = $tamano;
    $producto["precio"] = $precio;
    $producto["stock"] = $stock;
}

$conexion->close();

$categorias = [
    "Helado de crema",
    "Helado de agua",
    "Paleta",
    "Malteada",
    "Cono",
    "Postre helado",
    "Otro"
];

$sabores = [
    "Vainilla",
    "Chocolate",
    "Fresa",
    "Napolitano",
    "Galleta",
    "Mango",
    "Limón",
    "Vainilla con chocolate",
    "Mixto",
    "Otro"
];

$nombres = [
    "Helado de vainilla",
    "Helado de chocolate",
    "Helado de fresa",
    "Helado napolitano",
    "Helado de galleta",
    "Helado de mango",
    "Helado de limón",
    "Paleta de hielo",
    "Malteada",
    "Sundae",
    "Banana Split",
    "Otro"
];

$tamanos = [
    "Chico",
    "Mediano",
    "Grande",
    "1 bola",
    "2 bolas",
    "3 bolas",
    "Individual",
    "Familiar",
    "Unidad"
];
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Editar helado | IceCream Store</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f7f4fa;
            color: #333;
        }

        .sidebar {
            width: 240px;
            height: 100vh;
            background: #30243f;
            color: white;
            position: fixed;
            padding: 30px 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #ffb6d5;
            margin-bottom: 45px;
        }

        .sidebar p {
            margin: 22px 0;
            color: #ddd;
            font-size: 14px;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 13px;
            margin-bottom: 10px;
            border-radius: 8px;
        }

        .sidebar a:hover,
        .sidebar a.activo {
            background: #59446e;
        }

        .contenido {
            margin-left: 240px;
            padding: 35px;
        }

        .encabezado {
            margin-bottom: 30px;
        }

        .encabezado h1 {
            color: #30243f;
            font-size: 28px;
        }

        .encabezado p {
            color: #777;
            margin-top: 8px;
        }

        .formulario {
            background: white;
            padding: 30px;
            border-radius: 12px;
            max-width: 850px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.05);
        }

        .formulario h2 {
            color: #30243f;
            margin-bottom: 25px;
        }

        .campos {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .campo {
            display: flex;
            flex-direction: column;
            gap: 9px;
        }

        .campo label {
            font-weight: bold;
            font-size: 14px;
            color: #51445e;
        }

        input, select {
            width: 100%;
            padding: 13px;
            border: 1px solid #ddd;
            border-radius: 8px;
            outline: none;
            background: white;
        }

        input:focus, select:focus {
            border-color: #e96da6;
        }

        .botones {
            display: flex;
            gap: 12px;
            margin-top: 28px;
        }

        .boton {
            padding: 13px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
        }

        .guardar {
            background: #e96da6;
            color: white;
        }

        .guardar:hover {
            background: #d64f8e;
        }

        .cancelar {
            background: #eee;
            color: #444;
        }

        .error {
            background: #ffe5e5;
            color: #c0392b;
            padding: 13px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        @media(max-width: 650px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .contenido {
                margin-left: 0;
                padding: 18px;
            }

            .campos {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<div class="sidebar">

    <div class="logo">🍦 IceCream Store</div>

    <p>MENÚ PRINCIPAL</p>

    <a href="index.php">🏠 Panel principal</a>
    <a href="registrar.php">➕ Registrar helado</a>
    <a href="index.php" class="activo">📦 Inventario</a>

</div>

<div class="contenido">

    <div class="encabezado">
        <h1>Editar producto</h1>
        <p>Modifica la información del helado seleccionado.</p>
    </div>

    <div class="formulario">

        <h2>Información del producto</h2>

        <?php if ($error != ""): ?>
            <div class="error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="campos">

                <div class="campo">
                    <label>Nombre del helado</label>

                    <select name="nombre" required>
                        <?php foreach ($nombres as $opcion): ?>
                            <option value="<?php echo htmlspecialchars($opcion); ?>"
                                <?php echo ($producto["nombre"] == $opcion) ? "selected" : ""; ?>>
                                <?php echo htmlspecialchars($opcion); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label>Sabor</label>

                    <select name="sabor" required>
                        <?php foreach ($sabores as $opcion): ?>
                            <option value="<?php echo htmlspecialchars($opcion); ?>"
                                <?php echo ($producto["sabor"] == $opcion) ? "selected" : ""; ?>>
                                <?php echo htmlspecialchars($opcion); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label>Categoría</label>

                    <select name="categoria" required>
                        <?php foreach ($categorias as $opcion): ?>
                            <option value="<?php echo htmlspecialchars($opcion); ?>"
                                <?php echo ($producto["categoria"] == $opcion) ? "selected" : ""; ?>>
                                <?php echo htmlspecialchars($opcion); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label>Tamaño o presentación</label>

                    <select name="tamano" required>
                        <?php foreach ($tamanos as $opcion): ?>
                            <option value="<?php echo htmlspecialchars($opcion); ?>"
                                <?php echo ($producto["tamano"] == $opcion) ? "selected" : ""; ?>>
                                <?php echo htmlspecialchars($opcion); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label>Precio ($)</label>

                    <input
                        type="number"
                        name="precio"
                        step="0.01"
                        min="0.01"
                        value="<?php echo htmlspecialchars((string)$producto["precio"]); ?>"
                        required
                    >
                </div>

                <div class="campo">
                    <label>Existencias (stock)</label>

                    <input
                        type="number"
                        name="stock"
                        min="0"
                        step="1"
                        value="<?php echo htmlspecialchars((string)$producto["stock"]); ?>"
                        required
                    >
                </div>

            </div>

            <div class="botones">

                <button type="submit" class="boton guardar">
                    Guardar cambios
                </button>

                <a href="index.php" class="boton cancelar">
                    Cancelar
                </a>

            </div>

        </form>

    </div>

</div>

</body>
</html>
